$(document).ready(function(){
    alert("sdfsf");
})